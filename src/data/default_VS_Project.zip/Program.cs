﻿using static UnirayEngine.UnirayEngine;

namespace Program
{
    /// <summary>Represents an instance of the running program.</summary>
    public class Program
    {
        /// <summary>Defines the entrypoint of the program.</summary>
        /// <param name="args">Arguments passed from outside the app.</param>
        public static void Main(string[] args)
        {
            // Load engine configurations
            InitEngine();

            // Run game through engine
            RunEngine();

            // Close engine and unload data
            CloseEngine();
        }
    }
}